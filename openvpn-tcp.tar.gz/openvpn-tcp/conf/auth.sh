#!/bin/bash
secret_user="vinhbv"
secret_password="NSFW1986"
#
#
if [[ $username == $secret_user  &&  $password == "$secret_password" ]] ; then
   exit 0
else 
   exit 1
fi
