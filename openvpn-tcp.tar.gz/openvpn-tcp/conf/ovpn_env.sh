export OVPN_SERVER=172.16.8.0/23
#NAT device in container - always is eth0
export OVPN_NATDEVICE=eth0
iptables -I FORWARD -j ACCEPT
iptables -I FORWARD -p icmp -j ACCEPT
iptables -I FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
